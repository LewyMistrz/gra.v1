<?php
$i = mysqli_connect('localhost','root', '');
mysqli_select_db($i, "a");
?>